#include <iostream>
#include <vector>

using namespace std;

// v ordenado
// v[a..b] donde v[a] es el mínimo de v y v[b] es el máximo de v.
bool nifunifa(const vector<int> &v, int a, int b) {
    int r;
    if (b-a < 2 || v[a] == v[b]) {
        // 2 o menos elementos o segmento constante
        r = false;
    } else {
        // dividir por la mitad y seguir buscando en la mitad adecuada
        // mantengo m en el subvector para que se cumpla la precondición
        int m = (a+b)/2;
        if (v[m] == v[a])
            r = nifunifa(v, m, b);
        else if (v[m] == v[b])
            r = nifunifa(v, a, m);
        else
            r = true;
    }
    return r;
}

// Coste (sea n = b-a+1):
// T(n) = c0 si n <= 2
// T(n) = T(n/2) si n > 2
// luego a = 1, b = 2 y k = 0 -> O(log n)

bool solve() {
    int n;
    cin >> n;
    if (n == -1)
        return false;
    vector<int> v(n);
    for (int i=0; i<n; ++i)
        cin >> v[i];

    cout << (nifunifa(v, 0, v.size()-1) ? "SI" : "NO") << endl;
    return true;
}

int main() {
    while (solve());
    return 0;
}