#include <iostream>
#include <vector>

using namespace std;

// Pre: c > 0 and Forall k: 0 <= k < v.size(): v[k] >= 0
bool ctramo(const vector<int> &v, int c) {
    int i = 0, j = 0, s = 0;
    bool r = false;
    // Inv: 0 <= i <= j <= v.size() and
    //      s = Sum k: i <= k < j: v[k] and
    //      r = Exists k1, k2: 0 <= k1 <= k2 < j: es_ctramo(v, k1, k2, c)
    // Cota: 2 * v.size() - j - i
    while (j < v.size() && !r) {
        if (s + v[j] <= c) {
            s += v[j];
            ++j;
            r = s == c;
        } else {
            if (i < j) 
                s -= v[i];                
            else 
                ++j; // cuando v[i..j] es vacío avanzamos ambos índices
            ++i;
        }
    }
    return r;
}
// Post: r = Exists k1, k2: 0 <= k1 <= k2 < v.size(): es_ctramo(v, k1, k2, c)
// siendo
// es_ctramo(v, k1, k2, c) = (Sum k: k1 <= k <= k2: v[k]) == c

// Coste: O(v.size()) en el caso peor porque cada posición del vector se comprueba
// como máximo 2 veces. El caso peor es cuando no hay ningún ctramo o el único 
// ctramo llega hasta el final del vector. 

bool solve() {
    int n, c;
    cin >> n;
    if (n == -1)
        return false;
    vector<int> v(n);
    for (int i=0; i<n; ++i)
        cin >> v[i];
    cin >> c;

    cout << (ctramo(v, c) ? "SI" : "NO") << endl;
    return true;
}

int main() {
    while (solve());
    return 0;
}