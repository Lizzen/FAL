#include <iostream>
#include <vector>
#include <limits>
#include <algorithm>

using namespace std;

void loot_division(
    const vector<int> &values,      // values[i] es el valor de la moneda i
    int m,                          // min num de monedas para cada pirata
    vector<bool> &sol,              // sol[i] indica el pirata que se lleva la moneda i
    int k,                          // siguiente moneda a procesar
    int pval1, int pval2,           // valor de las monedas asignadas a cada pirata
    int pcoins1, int pcoins2,       // número de monedas asignadas a cada pirata
    int &min_diff,                  // mínima diferencia de valor alcanzable
    int &sol_counter) {             // número de soluciones con la diferencia mínima

    if (k == sol.size()) {
        // todas las monedas repartidas
        if (pcoins1 >= m && pcoins2 >= m) { 
            // cada pirata tiene las monedas necesarias
            int diff = abs(pval1 - pval2);
            if (diff < min_diff) {
                // nueva solución mejor
                min_diff = diff;
                sol_counter = 1;
            } else if (diff == min_diff) {
                // otra solución igual de buena
                ++sol_counter;
            }
        }
    } else {
        // asignar moneda k a pirata 1 
        // si quedan suficientes monedas para ambos piratas  
        if (max(m - pcoins1-1, 0) + max(m - pcoins2, 0) < values.size()-k) {
            sol[k] = false;
            loot_division(values, m, sol, k+1, pval1+values[k], pval2, pcoins1+1, pcoins2, min_diff, sol_counter);
        }

        // asignar moneda k a pirata 2
        // si quedan suficientes monedas para ambos piratas
        if (max(m - pcoins1, 0) + max(m - pcoins2-1, 0) < values.size()-k) {
            sol[k] = true;
            loot_division(values, m, sol, k+1, pval1, pval2+values[k], pcoins1, pcoins2+1, min_diff, sol_counter);
        }
    }
}

bool solve() {
    int n, m;
    cin >> n;
    if (n == -1)
        return false;
    cin >> m;
    vector<int> values(n);
    for (int i=0; i<n; ++i)
        cin >> values[i];

    vector<bool> sol(n);
    int min_diff = numeric_limits<int>::max();
    int sol_counter = 0;
    loot_division(values, m, sol, 0, 0, 0, 0, 0, min_diff, sol_counter);
    cout << min_diff << " " << sol_counter << endl;
    return true;
}

int main() {
    while (solve()) ;
    return 0;
}